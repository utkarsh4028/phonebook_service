const mongoose=require("mongoose");
const validator=require("validator");
const contactSchema=new mongoose.Schema({
    name:{
        type:String,
        required:true,
    },
    phone:{
        type:Number,
        min:10,
    },
    email:{
        type:String,
        required:true,
        unique:[true,"Email is already in use"],
        validate(value){
            if(!validator.isEmail(value)){
                throw new Error("Invalid");
            }
        }

    }
  
})
const Contact=new mongoose.model('Contact',contactSchema);
module.exports=Contact;